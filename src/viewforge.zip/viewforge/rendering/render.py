import os
from viewforge.template import HTML_TEMPLATE
from viewforge.plugins.shoelace.template import render_html as shoelace_render_html

def render_html(components, title="ViewForge App", use_shoelace=False):
    rendered = "\n".join(c.render() for c in components)

    if use_shoelace:
        print('Using shoelace')
        html = shoelace_render_html(components, title)
    else:
        html = HTML_TEMPLATE.format(title=title, content=rendered)

    out_path = os.path.abspath("web/index.html")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)

    return out_path  # file:// path for pywebview
