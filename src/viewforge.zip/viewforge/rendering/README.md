# Rendering

Handles HTML and DOM rendering logic.