# ViewForge Reorganized

This version organizes the ViewForge library into clear domains: core, state, routing, UI, and more.