import os
import webview
from viewforge.rendering.render import render_html
from viewforge.core.registry import handler_registry
from viewforge.routing.router import register_decorated_routes, _route_registry, router
from viewforge.routing.router_view import RouterView


class App:
    _instance = None

    def __init__(self, router=None, title: str = "ViewForge App"):
        self.window = None
        self.title = title
        self.router = router
        self._components = None
        App._instance = self
        self.api = API()

    def run(self, components=None, debug=False, use_shoelace=False):
        # Ensure decorated routes are registered before rendering
        if self.router is None and components is None and _route_registry:
            print("[App] Registering decorated routes...")
            self.router = register_decorated_routes()
            router().navigate("/")  # ensure initial route

        if components:
            if callable(components):
                print("[App] Building components...")
                self._components = components()
            else:
                self._components = components
            file_path = render_html(self._components, title=self.title, use_shoelace=use_shoelace)

        elif self.router:
            router().navigate(self.router.current_path if self.router.current_path else "/")
            file_path = render_html([RouterView()], title=self.title, use_shoelace=use_shoelace)

        else:
            file_path = os.path.abspath("web/empty.html")
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write("<h1>No components or router provided</h1>")

        print("[App] Creating window")
        print("Registered handlers:", list(handler_registry.get().keys()))
        self.window = webview.create_window(self.title, url=f"file://{file_path}", js_api=self.api)
        webview.start(debug=debug, http_server=True)

    def reload(self):
        from viewforge.rendering.render import render_html
        if self.window:
            if self.router:
                file_path = render_html([RouterView()], title=self.title)
                router().navigate(self.router.current_path or "/")  # Re-navigate to current path
            else:
                file_path = render_html(self._components, title=self.title)
            self.window.load_url(f"file://{file_path}")

    def evaluate_js(self, js_code: str):
        if self.window:
            return self.window.evaluate_js(js_code)

    @classmethod
    def current(cls):
        return cls._instance


class API:
    def handle_event(self, name, *args):
        print(f"[API] Handling event: {name} with args: {args}")
        handler = handler_registry.get().get(name)
        if handler:
            return handler(*args)
        raise ValueError(f"No handler named '{name}'")
