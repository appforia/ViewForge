import os
import webview
from viewforge.core.registry import handler_registry
from viewforge.routing.router import register_decorated_routes, router
from viewforge.routing.router_view import RouterView


class App:
    _instance = None

    def __init__(self, title: str = "ViewForge App"):
        self.window = None
        self.title = title
        self._components = None
        App._instance = self
        self.api = API()

    def run(self, components=None, debug=False):
        if components is None:
            print("[App] Router mode enabled — using registered @route views.")
            register_decorated_routes()
            router().navigate("/")

        if components:
            if callable(components):
                print("[App] Building components...")
                self._components = components()
            else:
                self._components = components

            file_path = App.inject_into_template(
                template_path="dist/index.html",
                out_path="web/index.html",
                components=self._components,
                placeholder="<!--VIEWFORGE-CONTENT-->"
            )

        else:
            current_path = router()()
            router().navigate(current_path or "/")
            file_path = App.inject_into_template(
                template_path="dist/index.html",
                out_path="web/index.html",
                components=[RouterView()],
                placeholder="<!--VIEWFORGE-CONTENT-->"
            )

        print("[App] Creating window")
        print("Registered handlers:", list(handler_registry.get().keys()))
        self.window = webview.create_window(self.title, url=f"file://{file_path}", js_api=self.api)
        webview.start(debug=debug, http_server=True)

    def reload(self):
        if self.window:
            if self._components:
                file_path = App.inject_into_template(
                    template_path="dist/index.html",
                    out_path="web/index.html",
                    components=self._components,
                    placeholder="<!--VIEWFORGE-CONTENT-->"
                )
            else:
                current_path = router()()
                router().navigate(current_path or "/")
                file_path = App.inject_into_template(
                    template_path="dist/index.html",
                    out_path="web/index.html",
                    components=[RouterView()],
                    placeholder="<!--VIEWFORGE-CONTENT-->"
                )
            self.window.load_url(f"file://{file_path}")

    def evaluate_js(self, js_code: str):
        if self.window:
            return self.window.evaluate_js(js_code)
        return None

    @staticmethod
    def inject_into_template(template_path, out_path, components, placeholder="<!--VIEWFORGE-CONTENT-->"):
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()

        rendered = "\n".join(c.render() for c in components)
        html = html.replace(placeholder, rendered)

        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(html)

        return os.path.abspath(out_path)

    @classmethod
    def current(cls):
        return cls._instance


class API:
    @staticmethod
    def handle_event(name, *args):
        print(f"[API] Handling event: {name} with args: {args}")
        handler = handler_registry.get().get(name)
        if handler:
            return handler(*args)
        raise ValueError(f"No handler named '{name}'")
