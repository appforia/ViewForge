# Core

Contains the App class, Component base class, and type registry.