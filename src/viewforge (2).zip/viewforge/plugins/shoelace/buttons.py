from viewforge.core.component import Component
from viewforge.state.signal import Signal


class ShoelaceButton(Component):
    def __init__(self, label: str | Signal, **props):
        self.label = label
        self._props = props
        super().__init__()

    def render(self):
        content = self.label() if isinstance(self.label, Signal) else self.label
        return f'<sl-button {" ".join(f"{k}={v!r}" for k, v in self._props.items())}>{content}</sl-button>'


class ShoelaceIconButton(Component):
    def __init__(self, name: str, library: str = "default", label: str = "", **props):
        self.name = name
        self.library = library
        self.label = label
        self._props = props
        super().__init__()

    def render(self):
        self._props["name"] = self.name
        self._props["library"] = self.library
        self._props["label"] = self.label
        return f'<sl-icon-button {" ".join(f"{k}={v!r}" for k, v in self._props.items())}></sl-icon-button>'


class ShoelaceButtonGroup(Component):
    def __init__(self, **props):
        self._props = props
        super().__init__()

    def render(self):
        return f'<sl-button-group {" ".join(f"{k}={v!r}" for k, v in self._props.items())}></sl-button-group>'


class ShoelaceCopyButton(Component):
    def __init__(self, value: str, **props):
        self.value = value
        self._props = props
        super().__init__()

    def render(self):
        self._props["value"] = self.value
        return f'<sl-copy-button {" ".join(f"{k}={v!r}" for k, v in self._props.items())}></sl-copy-button>'
