# UI Elements

Contains atomic UI elements like buttons, checkboxes, and inputs.